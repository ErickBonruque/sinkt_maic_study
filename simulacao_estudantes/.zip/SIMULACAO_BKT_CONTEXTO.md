# Simulação de Estudantes com BKT (Bayesian Knowledge Tracing)

## Visão Geral do Projeto

Este documento descreve o processo completo de simulação de estudantes sintéticos utilizando o modelo **BKT (Bayesian Knowledge Tracing)** para o projeto SINKT. O objetivo é gerar interações realistas de estudantes respondendo questões sobre conceitos de Linux, considerando diferentes perfis cognitivos e parâmetros de aprendizagem.

---

## 1. Perfis Cognitivos

### 1.1 Descrição dos Perfis

Foram criados **6 perfis cognitivos** distintos que representam diferentes tipos de estudantes. Cada perfil é caracterizado por 9 parâmetros fundamentais que influenciam o comportamento de aprendizagem:

#### **Parâmetros dos Perfis:**

1. **mastery_init_level** (0-1): Nível inicial de domínio do conteúdo
2. **learn_rate** (0-1): Taxa de aprendizagem (velocidade de aquisição de conhecimento)
3. **slip** (0-1): Probabilidade de erro quando o estudante sabe o conteúdo
4. **guess** (0-1): Probabilidade de acerto quando o estudante não sabe o conteúdo
5. **logic_skill** (0-1): Habilidade lógica e raciocínio algorítmico
6. **reading_skill** (0-1): Habilidade de interpretação de texto
7. **tech_familiarity** (0-1): Familiaridade com tecnologia e Linux
8. **memory_capacity** (0-1): Capacidade de retenção de memória
9. **learning_consistency** (0-1): Consistência e regularidade nos estudos

---

### 1.2 Perfis Definidos

#### **Perfil 1: Estudante Equilibrado (balanced)**
Perfil médio com habilidades balanceadas em todas as dimensões.

| Parâmetro | Valor | Peso/Influência |
|-----------|-------|-----------------|
| mastery_init_level | 0.55 | Domínio inicial moderado |
| learn_rate | 0.035 | Aprendizagem moderada |
| slip | 0.15 | Erro moderado quando sabe |
| guess | 0.15 | Acerto moderado quando não sabe |
| logic_skill | 0.55 | Habilidade lógica média |
| reading_skill | 0.55 | Interpretação média |
| tech_familiarity | 0.55 | Familiaridade média |
| memory_capacity | 0.55 | Retenção média |
| learning_consistency | 0.60 | Consistência moderada |

---

#### **Perfil 2: Aprendiz Rápido (quick_learner)**
Alta capacidade de aprendizagem e domínio inicial. Adquire conceitos rapidamente mas pode cometer erros por pressa.

| Parâmetro | Valor | Peso/Influência |
|-----------|-------|-----------------|
| mastery_init_level | 0.50 | Domínio inicial moderado |
| learn_rate | 0.08 | **Aprendizagem muito rápida** |
| slip | 0.18 | Erro elevado (pressa) |
| guess | 0.12 | Acerto baixo quando não sabe |
| logic_skill | 0.70 | **Habilidade lógica alta** |
| reading_skill | 0.65 | Interpretação boa |
| tech_familiarity | 0.80 | **Familiaridade alta** |
| memory_capacity | 0.80 | **Retenção alta** |
| learning_consistency | 0.85 | **Consistência alta** |

---

#### **Perfil 3: Estudante Cuidadoso (careful)**
Baixa taxa de erros quando sabe o conteúdo, mas aprende de forma mais gradual. Meticuloso e detalhista.

| Parâmetro | Valor | Peso/Influência |
|-----------|-------|-----------------|
| mastery_init_level | 0.45 | Domínio inicial moderado-baixo |
| learn_rate | 0.025 | Aprendizagem lenta |
| slip | 0.08 | **Erro muito baixo quando sabe** |
| guess | 0.10 | Acerto baixo quando não sabe |
| logic_skill | 0.60 | Habilidade lógica boa |
| reading_skill | 0.70 | **Interpretação alta** |
| tech_familiarity | 0.50 | Familiaridade média |
| memory_capacity | 0.70 | Retenção boa |
| learning_consistency | 0.90 | **Consistência muito alta** |

---

#### **Perfil 4: Estudante com Dificuldades (struggling)**
Baixo domínio inicial e lenta aprendizagem. Pode precisar de mais apoio e tempo para absorver conceitos.

| Parâmetro | Valor | Peso/Influência |
|-----------|-------|-----------------|
| mastery_init_level | 0.25 | **Domínio inicial baixo** |
| learn_rate | 0.015 | **Aprendizagem muito lenta** |
| slip | 0.25 | **Erro alto quando sabe** |
| guess | 0.20 | Acerto moderado quando não sabe |
| logic_skill | 0.30 | **Habilidade lógica baixa** |
| reading_skill | 0.35 | **Interpretação baixa** |
| tech_familiarity | 0.20 | **Familiaridade baixa** |
| memory_capacity | 0.40 | **Retenção baixa** |
| learning_consistency | 0.40 | **Consistência baixa** |

---

#### **Perfil 5: Pensador Lógico (logical)**
Excelente habilidade lógica mas com dificuldades em leitura. Excelente em problemas algorítmicos e matemáticos.

| Parâmetro | Valor | Peso/Influência |
|-----------|-------|-----------------|
| mastery_init_level | 0.50 | Domínio inicial moderado |
| learn_rate | 0.04 | Aprendizagem moderada |
| slip | 0.12 | Erro baixo quando sabe |
| guess | 0.08 | Acerto muito baixo quando não sabe |
| logic_skill | 0.85 | **Habilidade lógica muito alta** |
| reading_skill | 0.30 | **Interpretação baixa** |
| tech_familiarity | 0.60 | Familiaridade boa |
| memory_capacity | 0.60 | Retenção boa |
| learning_consistency | 0.75 | Consistência alta |

---

#### **Perfil 6: Estudante Intuitivo (intuitive)**
Boa intuição e habilidade de leitura, mas dificuldade com formalismo lógico. Aprende por exemplo e prática.

| Parâmetro | Valor | Peso/Influência |
|-----------|-------|-----------------|
| mastery_init_level | 0.40 | Domínio inicial moderado-baixo |
| learn_rate | 0.045 | Aprendizagem moderada-alta |
| slip | 0.16 | Erro moderado quando sabe |
| guess | 0.18 | Acerto moderado quando não sabe |
| logic_skill | 0.35 | **Habilidade lógica baixa** |
| reading_skill | 0.80 | **Interpretação muito alta** |
| tech_familiarity | 0.45 | Familiaridade moderada-baixa |
| memory_capacity | 0.65 | Retenção boa |
| learning_consistency | 0.65 | Consistência boa |

---

### 1.3 Estatísticas dos Perfis

| Parâmetro | Média | Desvio Padrão | Mínimo | Máximo |
|-----------|-------|---------------|--------|--------|
| mastery_init_level | 0.442 | 0.098 | 0.250 | 0.550 |
| learn_rate | 0.040 | 0.020 | 0.015 | 0.080 |
| slip | 0.157 | 0.052 | 0.080 | 0.250 |
| guess | 0.138 | 0.043 | 0.080 | 0.200 |
| logic_skill | 0.558 | 0.190 | 0.300 | 0.850 |
| reading_skill | 0.558 | 0.181 | 0.300 | 0.800 |
| tech_familiarity | 0.517 | 0.180 | 0.200 | 0.800 |
| memory_capacity | 0.617 | 0.125 | 0.400 | 0.800 |
| learning_consistency | 0.692 | 0.167 | 0.400 | 0.900 |

---

## 2. Geração de Estudantes Sintéticos

### 2.1 Configuração

- **Total de estudantes**: 100
- **Seed de reprodutibilidade**: 42
- **Variação individual**: ±15%

### 2.2 Distribuição por Perfil

| Perfil | Proporção | Quantidade |
|--------|-----------|------------|
| balanced | 30% | 30 estudantes |
| quick_learner | 20% | 20 estudantes |
| careful | 20% | 20 estudantes |
| struggling | 10% | 10 estudantes |
| logical | 10% | 10 estudantes |
| intuitive | 10% | 10 estudantes |

---

### 2.3 Fórmula de Geração

Cada estudante é gerado aplicando uma **variação individual aleatória** aos parâmetros do perfil base:

```
novo_valor = valor_perfil × (1 + ruído)
onde:
  ruído ~ Uniforme(-0.15, 0.15)
  novo_valor = clip(novo_valor, 0.0, 1.0)
```

**Exemplo prático:**
- Se `mastery_init_level` do perfil = 0.50
- E ruído = 0.10 (10% de aumento)
- Então: `novo_valor = 0.50 × (1 + 0.10) = 0.55`

Esta variação garante que:
1. Estudantes do mesmo perfil não sejam idênticos
2. A diversidade individual seja mantida
3. Os valores permaneçam dentro do intervalo válido [0, 1]

---

### 2.4 Estatísticas dos Estudantes Gerados

| Parâmetro | Média | Desvio Padrão | Mínimo | Máximo |
|-----------|-------|---------------|--------|--------|
| mastery_init_level | 0.469 | 0.094 | 0.231 | 0.631 |
| learn_rate | 0.041 | 0.021 | 0.013 | 0.089 |
| slip | 0.147 | 0.046 | 0.068 | 0.258 |
| guess | 0.136 | 0.037 | 0.071 | 0.229 |
| logic_skill | 0.580 | 0.169 | 0.265 | 0.962 |
| reading_skill | 0.580 | 0.156 | 0.265 | 0.907 |
| tech_familiarity | 0.549 | 0.174 | 0.175 | 0.911 |
| memory_capacity | 0.633 | 0.140 | 0.352 | 0.911 |
| learning_consistency | 0.704 | 0.168 | 0.346 | 1.000 |

---

## 3. Dados Utilizados

### 3.1 Conceitos de Linux

**Fonte**: `data/json/concepts_graph.json`

**Metadados**:
- Total de conceitos: **251**
- Total de relações: **322**
- Método de extração: Multi-Agent Council V2 (LangGraph Optimized)

**Estrutura de um conceito**:
```json
{
  "nome": "$PATH",
  "tipo": "SHELL_SCRIPT",
  "definicao": "Variável que armazena os diretórios nos quais o sistema deve buscar executáveis...",
  "capitulo_origem": "12",
  "id": "concept_000",
  "grau_entrada": 0,
  "grau_saida": 2,
  "grau_total": 2,
  "categoria": "Scripting_e_Automacao",
  "tamanho_definicao": 156,
  "nivel_detalhe": "INTERMEDIARIO",
  "quality_score": 1.0
}
```

**Exemplos de conceitos**:
1. **$PATH** (SHELL_SCRIPT): Variável que armazena diretórios de busca de executáveis
2. **\*** (SHELL_SCRIPT): Curinga para representar qualquer sequência de caracteres
3. **--help** (COMANDO): Parâmetro para obter ajuda rápida sobre comandos

**Categorias principais**:
- Scripting_e_Automacao
- Ferramentas_e_Comandos
- Sistema_de_Arquivos
- Gerenciamento_de_Processos
- Redes_e_Seguranca

---

### 3.2 Questões sobre Conceitos

**Fonte**: `data/json/questions_graph.json`

**Metadados**:
- Total de questões: **680**
- Questões por conceito (média): **2.71**

**Distribuição por tipo**:
- Multiple choice: 429 (63.1%)
- Descriptive: 251 (36.9%)

**Distribuição por dificuldade**:
- Easy: 251 (36.9%)
- Medium: 306 (45.0%)
- Hard: 123 (18.1%)

**Distribuição por nível Bloom**:
- Understand: 379 (55.7%)
- Apply: 178 (26.2%)
- Analyze: 123 (18.1%)

**Estrutura de uma questão**:
```json
{
  "id": "concept_000_q1",
  "c_id": "concept_000",
  "c_name": "$PATH",
  "c_type": "SHELL_SCRIPT",
  "type": "multiple_choice",
  "diff": "easy",
  "q": "O que é $PATH?",
  "exp": "$PATH: Variável que armazena os diretórios...",
  "rel": ["Variáveis de Ambiente", "/bin"],
  "kw": ["$path", "$path"],
  "bloom": "understand",
  "score": 2.0,
  "ans": "D",
  "opt": {
    "A": "Um comando para listar arquivos",
    "B": "Um tipo de permissão de arquivo",
    "C": "Um protocolo de rede",
    "D": "Variável que armazena os diretórios..."
  }
}
```

**Exemplos de questões**:

1. **Questão Easy (Multiple Choice)**:
   - Conceito: $PATH
   - Pergunta: "O que é $PATH?"
   - Tipo: Understand
   - Resposta: D

2. **Questão Medium (Multiple Choice)**:
   - Conceito: $PATH
   - Pergunta: "Para qual propósito é usado $PATH?"
   - Tipo: Apply
   - Resposta: A

---

## 4. Simulação de Interações com BKT

### 4.1 Configuração da Simulação

- **Interações por estudante**: 30-60 (aleatório)
- **Total de estudantes**: 100
- **Seed**: 42
- **Tipos de erro**: misconception, careless, slip, incomplete, misunderstanding

---

### 4.2 Cálculo da Probabilidade de Resposta Correta

A probabilidade de um estudante responder corretamente uma questão é calculada usando uma **versão estendida do BKT** que incorpora parâmetros cognitivos:

```python
def calculate_response_probability(student_params, question_difficulty):
    # Parâmetros BKT clássicos
    mastery = student_params['mastery_init_level']
    guess = student_params['guess']
    slip = student_params['slip']
    
    # Parâmetros cognitivos
    logic_skill = student_params['logic_skill']
    reading_skill = student_params['reading_skill']
    tech_familiarity = student_params['tech_familiarity']
    learning_consistency = student_params['learning_consistency']
    
    # Fator cognitivo (pesos: lógica=30%, leitura=20%, tech=10%)
    cognitive_factor = (logic_skill * 0.3 + 
                       reading_skill * 0.2 + 
                       tech_familiarity * 0.1)
    
    # Ajuste do mastery pela dificuldade e fatores cognitivos
    adjusted_mastery = (mastery * (1 - question_difficulty * 0.3) + 
                       cognitive_factor * 0.2)
    
    # Adiciona ruído se consistência for baixa
    if learning_consistency < 0.5:
        noise = Normal(0, (0.5 - learning_consistency) * 0.2)
        adjusted_mastery += noise
    
    # Fórmula BKT estendida
    prob = adjusted_mastery + (1 - adjusted_mastery) * guess - adjusted_mastery * slip
    
    return clip(prob, 0, 1)
```

**Componentes da fórmula**:

1. **Mastery ajustado**: Considera dificuldade da questão e habilidades cognitivas
2. **Guess**: Probabilidade de acerto por sorte quando não sabe
3. **Slip**: Probabilidade de erro por descuido quando sabe
4. **Ruído**: Adiciona inconsistência para estudantes com baixa consistência

---

### 4.3 Atualização do Domínio (Mastery Update)

Após cada interação, o domínio do estudante é atualizado:

```python
def update_mastery(current_mastery, is_correct, learn_rate, 
                   memory_capacity, time_gap):
    # Se acertou: aumenta o domínio
    if is_correct:
        current_mastery += (1 - current_mastery) * learn_rate
    # Se errou: diminui o domínio
    else:
        current_mastery *= (1 - learn_rate * 0.5)
    
    # Aplica decay temporal baseado na capacidade de memória
    if time_gap > 0:
        decay_factor = 1 - (1 - memory_capacity) * 0.1 * min(time_gap / 3600, 1)
        current_mastery *= max(0.3, decay_factor)
    
    return current_mastery
```

**Lógica de atualização**:

1. **Acerto**: Mastery aumenta proporcionalmente ao `learn_rate` e ao quanto falta para domínio completo
2. **Erro**: Mastery diminui pela metade do `learn_rate`
3. **Decay temporal**: Conhecimento decai com o tempo, influenciado pela `memory_capacity`
4. **Limite mínimo**: Mastery nunca cai abaixo de 0.3 (conhecimento residual)

---

### 4.4 Fluxo de Geração de Interações

Para cada estudante:

1. **Inicialização**:
   - Carregar parâmetros do estudante
   - Definir número aleatório de interações (30-60)
   - Inicializar mastery com `mastery_init_level`

2. **Loop de interações**:
   ```
   Para cada interação i:
     a) Selecionar questão aleatória
     b) Calcular probabilidade de acerto
     c) Simular resposta (correto/incorreto)
     d) Se incorreto: atribuir tipo de erro aleatório
     e) Atualizar mastery
     f) Registrar interação com timestamp
   ```

3. **Checkpoint**: Salvar progresso a cada 10 estudantes processados

---

### 4.5 Estrutura de uma Interação

```json
{
  "student_id": "student_0000",
  "question_id": "concept_262_q4",
  "is_correct": false,
  "mastery_before": 0.5293,
  "probability": 0.503,
  "error_type": "misconception",
  "timestamp": "2025-11-16T15:56:10.986065",
  "mastery_after": 0.4986
}
```

**Campos**:
- `student_id`: Identificador único do estudante
- `question_id`: Identificador da questão respondida
- `is_correct`: Se a resposta foi correta (true/false)
- `mastery_before`: Nível de domínio antes da interação
- `probability`: Probabilidade calculada de acerto
- `error_type`: Tipo de erro (null se correto)
- `timestamp`: Data/hora da interação
- `mastery_after`: Nível de domínio após a interação

---

## 5. Métricas da Simulação

### 5.1 Estatísticas Gerais

| Métrica | Valor |
|---------|-------|
| Total de interações | 4,528 |
| Total de estudantes | 100 |
| Interações por estudante (média) | 45.28 |
| Respostas corretas | 2,135 (47.2%) |
| Respostas incorretas | 2,393 (52.8%) |
| Tempo de processamento | 0.20s |

---

### 5.2 Estatísticas de Domínio (Mastery)

| Métrica | Valor |
|---------|-------|
| Média | 0.367 |
| Mediana | 0.364 |
| Desvio padrão | 0.126 |
| Mínimo | 0.058 |
| Máximo | 0.720 |

---

### 5.3 Distribuição de Tipos de Erro

| Tipo de Erro | Quantidade | Percentual |
|--------------|------------|------------|
| slip | 504 | 21.1% |
| misunderstanding | 495 | 20.7% |
| careless | 479 | 20.0% |
| misconception | 456 | 19.1% |
| incomplete | 459 | 19.2% |

**Interpretação**: A distribuição é equilibrada, indicando que todos os tipos de erro ocorrem com frequência similar.

---

### 5.4 Desempenho por Perfil Cognitivo

| Perfil | Estudantes | Acurácia Média | Desvio | Domínio Médio | Desvio |
|--------|------------|----------------|--------|---------------|--------|
| **quick_learner** | 20 | **48.3%** | ±4.9% | **0.518** | ±0.057 |
| **balanced** | 30 | 51.2% | ±9.6% | 0.360 | ±0.045 |
| **logical** | 10 | 49.8% | ±8.2% | 0.373 | ±0.041 |
| **careful** | 20 | 47.4% | ±8.3% | 0.345 | ±0.051 |
| **intuitive** | 10 | 43.6% | ±8.0% | 0.343 | ±0.032 |
| **struggling** | 10 | **33.4%** | ±9.4% | **0.132** | ±0.020 |

**Observações**:
- **quick_learner** tem o maior domínio médio (0.518), confirmando alta capacidade de aprendizagem
- **struggling** tem o menor desempenho (33.4% acurácia, 0.132 domínio)
- **balanced** tem maior variabilidade (±9.6%), indicando diversidade individual
- **quick_learner** tem menor variabilidade (±4.9%), indicando consistência

---

### 5.5 Correlação entre Parâmetros e Desempenho

#### Correlação com Acurácia

| Parâmetro | Correlação | Interpretação |
|-----------|------------|---------------|
| **mastery_init** | **+0.592** | Forte correlação positiva |
| **tech_familiarity** | +0.350 | Correlação moderada positiva |
| **slip** | **-0.336** | Correlação moderada negativa |
| **logic_skill** | +0.331 | Correlação moderada positiva |
| **guess** | -0.269 | Correlação fraca negativa |
| memory_capacity | +0.246 | Correlação fraca positiva |
| learning_consistency | +0.196 | Correlação fraca positiva |
| learn_rate | +0.183 | Correlação fraca positiva |
| reading_skill | +0.088 | Correlação muito fraca |

#### Correlação com Domínio Médio

| Parâmetro | Correlação | Interpretação |
|-----------|------------|---------------|
| **tech_familiarity** | **+0.868** | Correlação muito forte positiva |
| **memory_capacity** | **+0.849** | Correlação muito forte positiva |
| **learn_rate** | **+0.815** | Correlação muito forte positiva |
| **mastery_init** | **+0.714** | Correlação forte positiva |
| **logic_skill** | +0.574 | Correlação moderada positiva |
| **learning_consistency** | +0.565 | Correlação moderada positiva |
| **guess** | -0.485 | Correlação moderada negativa |
| reading_skill | +0.331 | Correlação fraca positiva |
| **slip** | -0.256 | Correlação fraca negativa |

---

### 5.6 Top 5 Fatores Mais Importantes

Baseado na correlação com acurácia:

1. **mastery_init** (0.592): Domínio inicial é o fator mais importante
2. **tech_familiarity** (0.350): Familiaridade com tecnologia
3. **slip** (-0.336): Erros por descuido (negativo)
4. **logic_skill** (0.331): Habilidade lógica
5. **guess** (-0.269): Acertos por sorte (negativo)

---

## 6. Conclusões e Insights

### 6.1 Validação do Modelo

1. **Diversidade realista**: Os 6 perfis geram comportamentos distintos e realistas
2. **Distribuição equilibrada**: Erros distribuídos uniformemente entre os tipos
3. **Correlações esperadas**: Parâmetros cognitivos correlacionam conforme esperado
4. **Variabilidade individual**: Variação de ±15% gera diversidade sem perder características do perfil

### 6.2 Fatores Críticos de Sucesso

1. **Domínio inicial** (`mastery_init`): Maior preditor de sucesso
2. **Familiaridade tecnológica**: Crucial para domínio a longo prazo
3. **Capacidade de memória**: Essencial para retenção de conhecimento
4. **Taxa de aprendizagem**: Determina velocidade de progressão

### 6.3 Próximos Passos

- Enriquecimento das interações com respostas textuais via LLM
- Geração de justificativas de erro personalizadas
- Validação com dados reais de estudantes
- Ajuste fino dos pesos dos parâmetros cognitivos

---

## 7. Arquivos Gerados

| Arquivo | Descrição | Tamanho |
|---------|-----------|---------|
| `data/output/notebooks/geracao_perfis/profiles.json` | 6 perfis cognitivos | ~2 KB |
| `data/output/notebooks/geracao_estudantes/students.json` | 100 estudantes sintéticos | ~50 KB |
| `data/output/notebooks/simulacao_interacoes/interactions_bkt.json` | 4,528 interações simuladas | 1.23 MB |

---

## 8. Referências Técnicas

### 8.1 Modelo BKT Clássico

```
P(correct) = P(L) * (1 - slip) + (1 - P(L)) * guess

onde:
  P(L) = probabilidade de ter aprendido (mastery)
  slip = probabilidade de erro quando sabe
  guess = probabilidade de acerto quando não sabe
```

### 8.2 Extensões Implementadas

1. **Parâmetros cognitivos**: Incorporação de habilidades individuais
2. **Ajuste por dificuldade**: Questões mais difíceis reduzem probabilidade de acerto
3. **Decay temporal**: Conhecimento decai com o tempo
4. **Ruído de consistência**: Estudantes inconsistentes têm maior variabilidade

---

**Documento gerado em**: 16 de dezembro de 2025  
**Versão do pipeline**: 3.0.0  
**Seed de reprodutibilidade**: 42
